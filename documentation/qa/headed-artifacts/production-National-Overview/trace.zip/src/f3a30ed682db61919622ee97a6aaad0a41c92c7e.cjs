const { test, expect } = require('@playwright/test');
const path = require('node:path');
const fs = require('node:fs/promises');

const screenshotDir = path.join(process.env.KAWASAN_QA_ROOT, 'documentation/qa/screenshots');
const heading = (page, name) => page.getByRole('heading', { name, exact: true });

async function step(name, fn) {
  console.log('RUN  ' + name);
  return test.step(name, async () => {
    try {
      const result = await fn();
      console.log('PASS ' + name);
      return result;
    } catch (error) {
      console.error('FAIL ' + name);
      throw error;
    }
  });
}

async function screenshot(page, name) {
  await fs.mkdir(screenshotDir, { recursive: true });
  await page.screenshot({ path: path.join(screenshotDir, 'headed-' + name + '.png'), fullPage: true, animations: 'disabled' });
}

test.beforeEach(async ({ page }, info) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => {
    if (message.type() === 'error') errors.push(message.text());
  });
  page.on('requestfailed', request => {
    const failure = request.failure()?.errorText;
    if (failure !== 'net::ERR_ABORTED') errors.push(failure + ' ' + request.url());
  });
  page.on('response', response => {
    if (response.status() >= 400) errors.push(response.status() + ' ' + response.url());
  });
  info.qaErrors = errors;
});
test.afterEach(async ({}, info) => {
  await step('Production browser console and network', () => expect(info.qaErrors).toEqual([]));
});

async function chartHover(page, section, chartIndex = 0) {
  const chart = section.locator('.recharts-wrapper').nth(chartIndex);
  await expect(chart).toBeVisible();
  const bar = chart.locator('.recharts-bar-rectangle path').first();
  await bar.scrollIntoViewIfNeeded();
  await bar.hover();
  await expect(chart.locator('.recharts-tooltip-wrapper')).toBeVisible();
}

test('National Overview', async ({ page }) => {
  await step('Load production Overview and 155 boundaries', async () => {
    await page.goto('/');
    await expect(page.getByText('155 matching districts')).toBeVisible();
    await expect(page.locator('.leaflet-interactive')).toHaveCount(155);
    await expect(page.getByText('66.92', { exact: true })).toBeVisible();
  });
  await step('Filter ranking by state and score band, sort, and paginate', async () => {
    await page.locator('label').filter({ hasText: /^State or territory/ }).locator('select').selectOption('Johor');
    await page.locator('label').filter({ hasText: /^KRDI band/ }).locator('select').selectOption({ index: 1 });
    await page.locator('label').filter({ hasText: /^Sort by/ }).locator('select').selectOption('score');
    await expect(page.getByRole('row').nth(1)).toContainText('Johor');
    await page.getByRole('button', { name: 'Reset filters' }).click();
    await page.getByRole('button', { name: 'Next', exact: true }).click();
    await expect(page.locator('tbody tr').first().locator('td').first()).toHaveText('16');
    await page.getByRole('button', { name: 'Previous', exact: true }).click();
  });
  await step('Hover ranking, distribution and state charts', async () => {
    for (const name of ['Five Highest-Ranked Districts', 'Five Lowest-Ranked Districts', 'Distribution of District KRDI Scores', 'Average District KRDI by State or Territory']) {
      await chartHover(page, heading(page, name).locator('xpath=ancestor::section[1]'));
    }
    await screenshot(page, 'overview');
  });
  await step('Zoom, hover and click a real district polygon', async () => {
    const map = page.locator('.leaflet-container');
    await map.scrollIntoViewIfNeeded();
    await map.getByRole('button', { name: 'Zoom in' }).click();
    await page.getByRole('button', { name: 'Reset map view' }).click();
    const point = await map.evaluate(el => {
      for (const polygon of el.querySelectorAll('path.leaflet-interactive')) {
        const box = polygon.getBoundingClientRect();
        if (box.width < 8 || box.height < 8) continue;
        for (let y = box.top + 2; y < box.bottom - 1; y += 3) {
          for (let x = box.left + 2; x < box.right - 1; x += 3) {
            if (document.elementFromPoint(x, y) === polygon) return { x, y };
          }
        }
      }
      return null;
    });
    expect(point).toBeTruthy();
    await page.mouse.move(point.x, point.y);
    await expect(page.locator('.leaflet-tooltip')).toContainText('KRDI');
    await page.mouse.click(point.x, point.y);
    await expect(page).toHaveURL(/\/districts\?district=/);
    await expect(heading(page, 'National District Benchmarking')).toBeVisible();
  });
});

test('District Intelligence', async ({ page }) => {
  await step('Open District Intelligence from navigation and switch state/district', async () => {
    await page.goto('/');
    await page.getByRole('link', { name: 'District Intelligence', exact: true }).click();
    await page.locator('label').filter({ hasText: /^State or territory/ }).locator('select').selectOption('Sarawak');
    await page.locator('select[aria-describedby]').selectOption('13_37');
    await expect(page).toHaveURL(/district=13_37/);
    await expect(heading(page, 'Bukit Mabong')).toBeVisible();
    await expect(page.getByRole('row', { name: 'Primary enrolment N/A' })).toBeVisible();
  });
  await step('Inspect development chart and zoom boundary', async () => {
    const radar = page.locator('.recharts-radar-polygon path');
    await expect(radar).toBeVisible();
    await radar.scrollIntoViewIfNeeded();
    await radar.hover();
    await page.locator('.leaflet-container').getByRole('button', { name: 'Zoom in' }).click();
    await page.getByRole('button', { name: 'Reset map view' }).click();
    await expect(page.locator('.leaflet-interactive')).toHaveCount(1);
    await screenshot(page, 'district-intelligence');
  });
  await step('Refresh shareable profile URL', async () => {
    await page.reload();
    await expect(heading(page, 'National District Benchmarking')).toBeVisible();
    await expect(page).toHaveURL(/district=13_37/);
    await expect(page.getByRole('link', { name: 'Investigate gaps' })).toHaveAttribute('href', '/gaps?district=13_37');
  });
});

test('Compare Districts', async ({ page }) => {
  await step('Open comparison and select both districts', async () => {
    await page.goto('/');
    await page.getByRole('link', { name: 'Compare Districts', exact: true }).click();
    await page.getByRole('group', { name: 'District A', exact: true }).locator('select[aria-describedby]').selectOption('1_2');
    await page.getByRole('group', { name: 'District B', exact: true }).locator('select[aria-describedby]').selectOption('13_37');
    await expect(heading(page, 'Dimension Scores')).toBeVisible();
    await expect(page.locator('tbody tr')).toHaveCount(9);
    await expect(page.getByText('56.19', { exact: true })).toBeVisible();
  });
  await step('Hover comparison bars and radar, then capture', async () => {
    await chartHover(page, heading(page, 'Dimension Scores').locator('xpath=ancestor::section[1]'));
    await page.locator('.recharts-radar-polygon path').first().hover();
    await screenshot(page, 'compare-districts');
  });
  await step('Swap districts and reject a duplicate pair', async () => {
    await page.getByRole('button', { name: 'Swap districts' }).click();
    await expect(page).toHaveURL(/\?a=13_37&b=1_2/);
    await expect(heading(page, 'Socioeconomic Comparison')).toBeVisible();
    await page.goto('/compare?a=1_2&b=1_2');
    await expect(page.getByText('Choose two different districts to compare.')).toBeVisible();
  });
});

test('Development Gaps', async ({ page }) => {
  await step('Open Development Gaps and select Bukit Mabong', async () => {
    await page.goto('/');
    await page.getByRole('link', { name: 'Development Gaps', exact: true }).click();
    await page.locator('label').filter({ hasText: /^State or territory/ }).locator('select').selectOption('Sarawak');
    await page.locator('select[aria-describedby]').selectOption('13_37');
    await expect(heading(page, 'Areas for Further Investigation')).toBeVisible();
    await expect(page.getByText('75 pp', { exact: true })).toBeVisible();
  });
  await step('Hover benchmark and infrastructure charts', async () => {
    for (const name of ['How the District Ranks Nationally', 'Infrastructure Access Shortfalls']) {
      await chartHover(page, heading(page, name).locator('xpath=ancestor::section[1]'));
    }
    await expect(page.getByRole('table').last().locator('tbody tr').first()).toContainText('Substantial shortfall');
    await screenshot(page, 'development-gaps');
  });
  await step('Follow the district profile link', async () => {
    await page.getByRole('link', { name: 'Open district profile' }).click();
    await expect(page).toHaveURL(/\/districts\?district=13_37/);
    await expect(heading(page, 'Bukit Mabong')).toBeVisible();
  });
});